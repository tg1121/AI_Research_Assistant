"""
Output cache — saves and loads pipeline results keyed by paper_id + reader profile.

Profile is bucketed to 1 decimal place so minor slider jitter (0.501 vs 0.499)
doesn't produce cache misses. The cache lives in outputs/ as:

    outputs/<paper_id>__e<expertise>_s<sci>_l<lang>.json

e.g. outputs/Thesis-2010110690__e0.0_s0.0_l0.0.json
"""

import json
import os
from ingestion.document import Document

OUTPUTS_DIR = "outputs"


def _profile_key(reader_expertise: float,
                 scientific_knowledge: float,
                 language_complexity: float) -> str:
    e = round(reader_expertise, 1)
    s = round(scientific_knowledge, 1)
    l = round(language_complexity, 1)
    return f"e{e}_s{s}_l{l}"


def cache_path(paper_id: str,
               reader_expertise: float,
               scientific_knowledge: float,
               language_complexity: float) -> str:
    key = _profile_key(reader_expertise, scientific_knowledge, language_complexity)
    return os.path.join(OUTPUTS_DIR, f"{paper_id}__{key}.json")


def load_cached(paper_id: str,
                reader_expertise: float,
                scientific_knowledge: float,
                language_complexity: float):
    """Return a Document if a cached result exists for this paper + profile, else None."""
    path = cache_path(paper_id, reader_expertise, scientific_knowledge, language_complexity)
    if not os.path.exists(path):
        return None
    print(f"  [cache hit] Loading {path}")
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    return Document.model_validate(data)


def save_cache(doc: Document,
               reader_expertise: float,
               scientific_knowledge: float,
               language_complexity: float) -> str:
    """Save doc to cache. Returns the path written."""
    os.makedirs(OUTPUTS_DIR, exist_ok=True)
    path = cache_path(doc.paper_id, reader_expertise, scientific_knowledge, language_complexity)
    with open(path, "w", encoding="utf-8") as f:
        f.write(doc.model_dump_json(indent=2))
    print(f"  [cache saved] {path}")
    return path


def list_cached_profiles(paper_id: str) -> list[dict]:
    """Return all cached profiles for a given paper_id as a list of dicts."""
    if not os.path.exists(OUTPUTS_DIR):
        return []
    profiles = []
    prefix = f"{paper_id}__"
    for fname in sorted(os.listdir(OUTPUTS_DIR)):
        if fname.startswith(prefix) and fname.endswith(".json"):
            key = fname[len(prefix):-5]
            try:
                # key looks like e0.5_s0.3_l0.7
                tokens = key.split("_")
                parsed = {}
                for t in tokens:
                    parsed[t[0]] = float(t[1:])
                profiles.append({
                    "file": fname,
                    "reader_expertise":    parsed.get("e", 0.0),
                    "scientific_knowledge": parsed.get("s", 0.0),
                    "language_complexity":  parsed.get("l", 0.0),
                })
            except Exception:
                pass
    return profiles
